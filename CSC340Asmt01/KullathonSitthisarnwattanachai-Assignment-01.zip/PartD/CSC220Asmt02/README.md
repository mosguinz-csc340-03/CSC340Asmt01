# CSC 220 — Assignment 02

[![Run on Repl.it](https://repl.it/badge/github/mosguinz-csc220-02/CSC220Asmt02)](https://repl.it/github/mosguinz-csc220-02/CSC220Asmt02)

## Quick links

* [Assignment](https://github.com/mosguinz-csc220-02/CSC220Asmt02/blob/main/CSC220Asmt02/Assignment-02.pdf)
* [Assignment Resources](https://github.com/mosguinz-csc220-02/CSC220Asmt02/tree/main/CSC220Asmt02/Resources)
* [Javadoc](https://mosguinz-csc220-02.github.io/CSC220Asmt02/), including private methods and fields. *Incomplete, but it’s there. No intentions of completing it.*
* [Report](https://github.com/mosguinz-csc220-02/CSC220Asmt02/blob/main/CSC220Asmt02/KullathonSitthisarnwattanachai-Assignment-02-Report.pdf)
* [Presentation Slides](https://github.com/mosguinz-csc220-02/CSC220Asmt02/blob/main/CSC220Asmt02/Assignment-02-Presentation.pdf)
* [ZIP Archive on File Manager](http://csc220.ducta.net/Assignments/Assignment-02-MosKullathon.zip)

## Note
The main branch contains post-submission amendments that were not considered for grading. To browse the code in the state they were submitted, see the [original-submission](https://github.com/mosguinz-csc220-02/CSC220Asmt02/tree/original-submission) branch.

## Questions or comments?
If you have any questions or comments about the project, please add them in the [Discussions tab](https://github.com/mosguinz-csc220-02/CSC220Asmt02/discussions/new).
